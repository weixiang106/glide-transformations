package com.gavin.com.library.listener;

/**
 * Created by gavin
 * Created date 17/5/25
 */

public interface GroupListener {
    String getGroupName(int position);
}
