package com.gavin.com.library.listener;

/**
 * @author gavin
 * date 17/11/18
 * description 头部点击事件
 */

public interface OnGroupClickListener {
    void onClick(int position, int id);
}
