package com.gavin.apmtools;

/**
 * Created by gavin
 * date 2018/5/30
 */
public interface TimerCallback {
    void onCallBack();
}
