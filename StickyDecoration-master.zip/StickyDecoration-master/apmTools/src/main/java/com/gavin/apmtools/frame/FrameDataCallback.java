package com.gavin.apmtools.frame;


import java.util.List;

/**
 * Created by gavin
 * date 2018/5/30
 */
public interface FrameDataCallback {
    void getFPS(List<Long> pfs);
}
